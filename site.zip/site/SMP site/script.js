particlesJS("particles-js", {
  "particles": {
    "number": { "value": 80 }, // Количество точек
    "color": { "value": "#b0b0b0" }, // Цвет точек (светло-серый)
    "shape": { "type": "circle" },
    "opacity": { "value": 0.5 },
    "size": { "value": 3 },
    "line_linked": {
      "enable": true,
      "distance": 150,
      "color": "#d3d3d3", // Цвет линий между точками
      "opacity": 0.4,
      "width": 1
    },
    "move": { "enable": true, "speed": 2 }
  },
  "interactivity": {
    "events": {
      "onhover": { "enable": true, "mode": "grab" }, // Линии тянутся к мышке
      "onclick": { "enable": true, "mode": "push" }  // Добавляет точки при клике
    }
  }
});

